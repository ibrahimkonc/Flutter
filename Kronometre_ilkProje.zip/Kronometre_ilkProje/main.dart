import 'package:flutter/material.dart';

import 'i_app.dart';

void main() {
  runApp(const IApp());
}
